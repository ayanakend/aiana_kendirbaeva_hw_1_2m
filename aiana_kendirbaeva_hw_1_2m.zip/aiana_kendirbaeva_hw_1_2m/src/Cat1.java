public final class Cat1 extends Cats{
    public Cat1(Integer age, colorOfAnimal color) {
        super(age, color);
    }

    public Cat1(Integer age, colorOfAnimal color, double weight) {
        super(age, color, weight);

    }


    @Override
    public Integer getAge() {
        return super.getAge();
    }
}
