import java.util.Random;

public class Color {
    enum color {
        BLACK, WHITE, GRAY, BROWN
    }
}
