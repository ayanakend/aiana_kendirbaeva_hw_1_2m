public class Breed{
    enum breed{
        ASIAN, BENGAL, BURMILLA
    }
}
