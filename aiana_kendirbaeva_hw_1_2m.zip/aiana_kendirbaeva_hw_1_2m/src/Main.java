public class Main {
    public static void main(String[] args) {
        Shelter shelter = new Shelter("Sun", "Vol st. 37/4");

        Dog South = new Dog(shelter, Pet.generateDefaultAge(), Color.color.GRAY);
        System.out.println(South.getInfo());
        South.makeVoice();

        Dog Mack = new Dog(Pet.generateDefaultAge(), Color.color.WHITE, shelter, "Mack", "fighting dog", new String[]{"Лежать", "Голос"});
        System.out.println(Mack.getInfo());
        Mack.makeVoice("woof", 5);

        Dog Rick = new Dog();
        System.out.println(Rick.getInfo());
        Rick.makeVoice(3, "woof");

        System.out.println("------------------------------------------------------------------");

        Cats objectA = new Cats(3, Animal.colorOfAnimal.WHITE, 3.7);
        System.out.println(objectA);
        Cat1 objectB = new Cat1(5, Animal.colorOfAnimal.GRAY);
        System.out.println(objectB);
        Cat1 objectC = new Cat1(2, Animal.colorOfAnimal.BLACK, 2.3);
        System.out.println(objectC);
    }
}